/**
 * Extensions and integration means to other products.
 */
package org.jgrapht.ext;
