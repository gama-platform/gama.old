/**
 * Algorithms for (sub)graph isomorphism.
 */
package org.jgrapht.alg.isomorphism;
