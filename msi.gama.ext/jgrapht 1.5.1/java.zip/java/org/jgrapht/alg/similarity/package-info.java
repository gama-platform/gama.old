/**
 * Algorithms for computing graph similarity metrics.
 */
package org.jgrapht.alg.similarity;
