module org.jgrapht.ext
{
    exports org.jgrapht.ext;

    requires transitive org.jgrapht.core;
    requires transitive com.github.vlsi.mxgraph.jgraphx;
}
