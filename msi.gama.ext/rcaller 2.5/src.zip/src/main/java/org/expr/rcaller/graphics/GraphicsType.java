package org.expr.rcaller.graphics;

public enum GraphicsType {

    bmp,
    jpeg,
    tiff,
    png
}
