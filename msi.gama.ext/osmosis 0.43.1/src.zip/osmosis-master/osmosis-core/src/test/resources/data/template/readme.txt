The following substitutions are performed on files in this directory.

%VERSION% - Replaced with the current osmosis version, useful for updating xml files.
