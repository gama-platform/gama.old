The source code in this directory is copyrighted code that is licensed
to individuals or companies who download or otherwise access the code.

The copyright notice for the vecmath source code is in the
javax/COPYRIGHT.txt file.

The license for the vecmath source code is in the javax/LICENSE.txt
file.

Note that the source files in this directory are not sufficient to
build vecmath. If you want to build vecmath, you can use CVS to get a
complete source tree.  See
https://vecmath.dev.java.net/build-instr.html for more information.
